package com.example.aplikacja_final

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import androidx.navigation.fragment.findNavController

class Resistance_Fragment : Fragment() {

    private val multiplierMap = listOf(1, 1_000, 1_000_000)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_resistance_, container, false)

        val home_button = view.findViewById<Button>(R.id.bt_go_home_2)
        home_button.setOnClickListener{findNavController().navigate(R.id.action_resistance_Fragment2_to_home_Fragment2)}

        val bmi_button = view.findViewById<Button>(R.id.bt_go_BMI)
        bmi_button.setOnClickListener{findNavController().navigate(R.id.action_resistance_Fragment2_to_BMI_Fragment2)}

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val etR1 = view.findViewById<EditText>(R.id.et_R1)
        val etR2 = view.findViewById<EditText>(R.id.et_R2)
        val spinner1 = view.findViewById<Spinner>(R.id.sp_1)
        val spinner2 = view.findViewById<Spinner>(R.id.sp_2)
        val button = view.findViewById<Button>(R.id.bt_Result)
        val output = view.findViewById<TextView>(R.id.tv_R_out)

        // Adapter dla spinnerów
        val adapter = ArrayAdapter.createFromResource(
            requireContext(),
            R.array.resistance_decades,
            android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner1.adapter = adapter
        spinner2.adapter = adapter

        button.setOnClickListener {
            try {
                val r1 = etR1.text.toString().toDouble()
                val r2 = etR2.text.toString().toDouble()

                val multiplier1 = multiplierMap[spinner1.selectedItemPosition]
                val multiplier2 = multiplierMap[spinner2.selectedItemPosition]

                val total = (r1 * multiplier1) + (r2 * multiplier2)

                // Formatowanie jednostki
                val (displayValue, unit) = when {
                    total >= 1_000_000 -> Pair(total / 1_000_000, "MΩ")
                    total >= 1_000 -> Pair(total / 1_000, "kΩ")
                    else -> Pair(total, "Ω")
                }

                // Wyświetlenie wyniku z ładną jednostką
                output.text = "Obliczona Rezystancja = %.2f %s".format(displayValue, unit)

            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Wprowadź poprawne dane liczbowe", Toast.LENGTH_SHORT).show()
            }
        }
    }

}
