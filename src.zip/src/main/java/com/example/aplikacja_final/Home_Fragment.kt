package com.example.aplikacja_final

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController

class Home_Fragment : Fragment() {


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view =  inflater.inflate(R.layout.fragment_home_, container, false)

        val BMI_button = view.findViewById<Button>(R.id.bt_BMI)
        BMI_button.setOnClickListener{findNavController().navigate(R.id.action_home_Fragment2_to_BMI_Fragment2)}

        val R_button = view.findViewById<Button>(R.id.bt_R)
        R_button.setOnClickListener{findNavController().navigate(R.id.action_home_Fragment2_to_resistance_Fragment2)}

        return view
    }
}
