package com.example.aplikacja_final

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import kotlin.math.pow
import android.graphics.Color
import androidx.navigation.fragment.findNavController

class BMI_Fragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view =  inflater.inflate(R.layout.fragment_b_m_i_, container, false)

        val Resistance_button = view.findViewById<Button>(R.id.bt_go_R)
        Resistance_button.setOnClickListener{findNavController().navigate(R.id.action_BMI_Fragment2_to_resistance_Fragment2)}

        val Home_button = view.findViewById<Button>(R.id.bt_go_home)
        Home_button.setOnClickListener{findNavController().navigate(R.id.action_BMI_Fragment2_to_home_Fragment2)}

        val weight = view.findViewById<EditText>(R.id.et_weight)
        val height = view.findViewById<EditText>(R.id.et_height)
        val bmi = view.findViewById<TextView>(R.id.tv_result)
        val calculate = view.findViewById<Button>(R.id.btn_calculate)
        val state_txt = view.findViewById<TextView>(R.id.tv_state)

        var result = 0.00


        calculate.setOnClickListener {
            val weight_flt = weight.text.toString().toDoubleOrNull()
            val height_flt = height.text.toString().toDoubleOrNull()

            if (weight_flt != null && height_flt != null) {
                result = weight_flt / (height_flt / 100).pow(2)

                val color = when {
                    result < 18.5 -> "#2196F3"
                    result < 25.0 -> "#4CAF50"
                    result < 30.0 -> "#FFEB3B"
                    result < 35 -> "#FF9800"
                    else -> "#F44336"
                }

                val state = when {
                    result < 18.5 -> "UNDERWEIGHT"
                    result < 25.0 -> "NORMAL"
                    result < 30.0 -> "OVERWEIGHT"
                    result < 35 -> "OBESE"
                    else -> "GO TO THE GYM!!!"
                }

                bmi.text = ("BMI\n" + String.format("%.1f", result))
                bmi.setTextColor(Color.parseColor(color))

                state_txt.text = "Your state is: $state"
                state_txt.setTextColor(Color.parseColor(color))

            } else {
                Toast.makeText(requireContext(), "Wrong data input", Toast.LENGTH_SHORT).show()
            }
        }

    return view
    }
}
